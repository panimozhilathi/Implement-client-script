# Implement Client Script & UI Policy (Incident)

**Team ID:** 6ab8d072c23107aaaa72f9d7

**Team Members**
- K. Panimozhi
- J. Lathika
- M. Vasimalaiyan

## Project Overview
This repository contains the phase-wise documentation for the ServiceNow micro project **Implement Client Script & UI Policy (Incident)**.

## 8 Phases
1. Ideation Phase
2. Requirement Analysis
3. Project Design Phase
4. Project Planning Phase
5. Project Development Phase
6. Project Testing Phase
7. Project Documentation
8. Project Demonstration

## Implementation Summary
- UI Policy: **High Impact Control**
- Condition: **Impact = 1 - High**
- Assignment group: **Mandatory**
- Urgency: **Read-only** when the condition is true
- onChange Client Script: Automatically sets Urgency to High
- onSubmit Client Script: Prevents save when Assigned To is empty for High Impact
- onCellEdit Client Script: Blocks direct State list editing
- Form-based State update: Allowed

## Evidence
Add your actual ServiceNow screenshots to the `ServiceNow_Screenshots` folder before final submission. Do not use placeholder screenshots as proof of implementation.

## Submission
Upload this project structure to the GitHub repository assigned for the SmartBridge/SkillWallet project and submit the public repository link.
